﻿# PackMannjNodeJs

L.A.R.S.'s contribution to [the competition in artifical intelligence](https://github.com/sandsmark/aicompo-tg17) at The Gathering 2017. 

Implemented in Node.js.

To run:

```$ node lars.js -s server_address:server_port -n bot_nick```

The -s and -n flags are optional, and default to *127.0.0.1:54321* and *L.A.R.S.*, respectively.